import { GoogleGenAI } from "@google/genai";

// Fix: Initializing GoogleGenAI globally with process.env.API_KEY as per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
Você é o "Consultor Soberano", um especialista em pedras ornamentais (mármores, granitos, quartzos e lâminas sintéticas) da empresa Soberano Mármore.
Sua missão é ajudar clientes a escolherem o material ideal para seus projetos.
Sua linguagem deve ser elegante, técnica porém acessível, transmitindo luxo e autoridade.
Mencione nomes de pedras como Carrara, Calacatta, Nero Marquina, e Quartzitos quando apropriado.
Considere fatores como: porosidade, resistência a riscos, calor e absorção de líquidos ao dar recomendações para cozinhas, banheiros ou áreas externas.
Localização da empresa: Salto-SP, atendendo Itu e Indaiatuba.
`;

export async function getStoneAdvice(userQuery: string, history: { role: 'user' | 'model', text: string }[]) {
  const chatHistory = history.map(h => ({
    role: h.role === 'user' ? 'user' : 'model',
    parts: [{ text: h.text }]
  }));

  try {
    // Fix: Using the pre-initialized 'ai' instance and ensuring correct model name for text tasks
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...chatHistory,
        { role: 'user', parts: [{ text: userQuery }] }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      }
    });

    // Fix: Accessing .text as a property directly as per latest SDK documentation
    return response.text || "Desculpe, tive um problema ao processar sua consulta. Por favor, tente novamente.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Lamento, o serviço de consultoria inteligente está indisponível no momento. Por favor, entre em contato via WhatsApp.";
  }
}