
import React, { useState, useRef, useEffect } from 'react';
import { getStoneAdvice } from '../services/geminiService';
import { ChatMessage } from '../types';

const StoneConsultant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Olá, sou o Consultor Soberano via IA. Deseja tirar dúvidas técnicas ou prefere falar com um atendente humano no WhatsApp?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    const response = await getStoneAdvice(userMsg, messages);
    setMessages(prev => [...prev, { role: 'model', text: response }]);
    setIsLoading(false);
  };

  const handleWhatsAppDirect = () => {
    window.open('https://wa.me/5511968143372', '_blank');
  };

  return (
    <>
      {/* Trigger Button (WhatsApp Icon) */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white w-16 h-16 rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-transform animate-bounce"
      >
        <i className="fab fa-whatsapp text-4xl"></i>
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-80 md:w-96 h-[500px] glass rounded-3xl overflow-hidden shadow-2xl flex flex-col border border-gold/30">
          {/* Header */}
          <div className="bg-midnight p-4 border-b border-gold/20 flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center text-midnight font-bold">
                <i className="fab fa-whatsapp"></i>
              </div>
              <div>
                <h3 className="text-white text-sm font-bold">Consultor Soberano</h3>
                <span className="text-emerald-400 text-[10px] flex items-center">
                  <span className="w-2 h-2 bg-emerald-400 rounded-full mr-1 animate-pulse"></span> Online
                </span>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-midnight/80">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-3 rounded-2xl text-sm ${
                  msg.role === 'user' 
                    ? 'bg-gold text-midnight rounded-tr-none' 
                    : 'glass text-slate-100 rounded-tl-none border border-white/10'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="glass p-3 rounded-2xl rounded-tl-none text-slate-300 text-sm italic">
                  Analisando...
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Action Footer */}
          <div className="p-4 bg-midnight border-t border-gold/20 space-y-3">
            <button 
              onClick={handleWhatsAppDirect}
              className="w-full bg-[#25D366] text-white py-2 rounded-full text-xs font-bold tracking-widest flex items-center justify-center space-x-2"
            >
              <i className="fab fa-whatsapp"></i>
              <span>FALAR COM HUMANO AGORA</span>
            </button>
            <div className="flex space-x-2">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ou pergunte à nossa IA..."
                className="flex-1 bg-white/5 border border-white/10 rounded-full px-4 py-2 text-white text-[10px] focus:outline-none focus:border-gold transition-colors"
              />
              <button 
                onClick={handleSend}
                disabled={isLoading}
                className="bg-gold text-midnight w-8 h-8 rounded-full flex items-center justify-center hover:bg-yellow-500 transition-colors disabled:opacity-50"
              >
                <i className="fas fa-paper-plane text-xs"></i>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default StoneConsultant;
