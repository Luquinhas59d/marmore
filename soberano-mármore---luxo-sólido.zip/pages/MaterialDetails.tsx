
import React, { useMemo } from 'react';
import { MATERIALS } from '../constants'; 

interface Review {
  id: string;
  name: string;
  date: string;
  rating: number;
  comment: string;
  location: string;
  tag: string;
}

const REVIEWS: Review[] = [
  {
    id: 'r1',
    name: 'Dr. Ricardo Silveira',
    date: '14 de Janeiro, 2024',
    rating: 5,
    tag: 'Cliente Residencial',
    comment: 'O acabamento em meia esquadria que a Soberano executou com este material na minha ilha gourmet ficou impecável. A continuidade dos veios é arte pura.',
    location: 'Terras de São José, Itu'
  },
  {
    id: 'r2',
    name: 'Mariana Drummond',
    date: '02 de Dezembro, 2023',
    rating: 5,
    tag: 'Proprietária',
    comment: 'Estava em dúvida sobre a resistência, mas a consultoria técnica me deu segurança. Instalado há 6 meses e continua com o brilho do primeiro dia.',
    location: 'Helvetia, Indaiatuba'
  },
  {
    id: 'r3',
    name: 'Arq. Felipe Bastos',
    date: '20 de Outubro, 2023',
    rating: 5,
    tag: 'Arquiteto Especialista',
    comment: 'Como especificador, prezo pela fidelidade da amostra com a chapa final. A Soberano entrega exatamente o que promete em termos de nobreza e seleção.',
    location: 'Residencial Moutonnée, Salto'
  }
];

interface MaterialDetailsProps {
  id: string;
  onBack: () => void;
  onSelectMaterial: (id: string) => void;
}

const MaterialDetails: React.FC<MaterialDetailsProps> = ({ id, onBack, onSelectMaterial }) => {
  const material = useMemo(() => MATERIALS.find(m => m.id === id), [id]);

  const suggestedMaterials = useMemo(() => {
    if (!material) return [];
    const others = MATERIALS.filter(m => m.id !== id);
    return others.slice(0, 3);
  }, [id, material]);

  const handleImgError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    e.currentTarget.src = "https://images.unsplash.com/photo-1516961642265-531546e84af2?auto=format,compress&fit=crop&w=1200&q=80";
  };

  if (!material) return null;

  return (
    <div className="pt-32 pb-24 bg-[#0F172A] min-h-screen animate-in fade-in duration-700">
      <div className="container mx-auto px-6">
        <button onClick={onBack} className="text-slate-400 text-[10px] font-bold tracking-[0.3em] mb-12 hover:text-[#D4AF37] transition-colors">
          <i className="fas fa-chevron-left mr-2"></i> VOLTAR PARA COLEÇÕES
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-32">
          {/* Imagem Principal */}
          <div className="rounded-[40px] overflow-hidden border border-white/5 shadow-2xl relative group">
            <img 
              src={material.image} 
              alt={material.name} 
              onError={handleImgError}
              className="w-full h-[600px] object-cover transition-transform duration-[3s] group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-transparent to-transparent opacity-60"></div>
          </div>

          {/* Info do Material */}
          <div className="flex flex-col justify-center">
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex text-[#D4AF37] text-[10px]">
                {[...Array(5)].map((_, i) => <i key={i} className="fas fa-star"></i>)}
              </div>
              <span className="text-slate-500 text-[10px] tracking-widest font-bold uppercase">4.9 / 5 Baseado em Projetos Reais</span>
            </div>
            
            <h1 className="text-[#D4AF37] text-6xl md:text-8xl font-serif mb-8 leading-none">{material.name}</h1>
            <p className="text-slate-300 text-xl font-light italic leading-relaxed border-l-2 border-[#D4AF37]/30 pl-8 mb-12">
              "{material.description}"
            </p>

            <button 
              onClick={() => window.open(`https://wa.me/5511968143372?text=Orcamento: ${material.name}`, '_blank')}
              className="bg-[#D4AF37] text-[#0F172A] px-12 py-6 rounded-full font-bold tracking-[0.2em] hover:bg-white transition-all transform hover:-translate-y-1 w-fit"
            >
              SOLICITAR ORÇAMENTO
            </button>
          </div>
        </div>

        {/* SEÇÃO DE AVALIAÇÕES */}
        <section className="mb-32">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16">
            <div className="max-w-xl">
              <span className="text-[#D4AF37] tracking-[0.5em] text-[10px] font-bold mb-4 block uppercase">Prova Social</span>
              <h2 className="text-white text-4xl md:text-5xl font-serif">Experiências <span className="text-[#D4AF37] italic">Soberanas</span></h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {REVIEWS.map((review) => (
              <div key={review.id} className="glass p-10 rounded-[40px] border-white/10 relative overflow-hidden group hover:border-[#D4AF37]/30 transition-all flex flex-col h-full">
                <div className="flex justify-between items-start mb-8">
                  <div className="flex text-[#D4AF37] space-x-1">
                    {[...Array(review.rating)].map((_, i) => <i key={i} className="fas fa-star text-[10px]"></i>)}
                  </div>
                  <span className="text-[#D4AF37] text-[8px] tracking-[0.3em] font-bold uppercase py-1 px-3 border border-[#D4AF37]/20 rounded-full">{review.tag}</span>
                </div>
                <p className="text-slate-200 text-lg font-light leading-relaxed mb-10 italic flex-1">"{review.comment}"</p>
                <div className="mt-auto">
                  <span className="text-white font-serif text-xl block">{review.name}</span>
                  <span className="text-[#D4AF37] text-[10px] font-bold tracking-widest uppercase">{review.location}</span>
                </div>
                <i className="fas fa-quote-right absolute bottom-10 right-10 text-white/5 text-6xl"></i>
              </div>
            ))}
          </div>
        </section>

        {/* Sugestões */}
        <section className="pt-24 border-t border-white/10">
          <h2 className="text-white text-4xl font-serif mb-16">Materiais Similares</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {suggestedMaterials.map((suggested) => (
              <div 
                key={suggested.id}
                onClick={() => { onSelectMaterial(suggested.id); window.scrollTo(0, 0); }}
                className="group cursor-pointer bg-white/5 rounded-[40px] overflow-hidden border border-white/5 hover:border-[#D4AF37]/30 transition-all"
              >
                <div className="h-64 overflow-hidden relative">
                  <img src={suggested.image} alt={suggested.name} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
                </div>
                <div className="p-10">
                  <h3 className="text-white text-2xl font-serif group-hover:text-[#D4AF37] transition-colors">{suggested.name}</h3>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default MaterialDetails;
