
import React, { useState, useEffect, useRef } from 'react';
import { MATERIALS } from '../constants';

interface HomeProps {
  onNavigate: (page: string) => void;
}

const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  const [imgLoaded, setImgLoaded] = useState(false);
  const [sectionVisible, setSectionVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setSectionVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleImgError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    e.currentTarget.src = "https://i.postimg.cc/bvMrCvsP/luxo.jpg";
  };

  return (
    <div className="animate-in fade-in duration-1000">
      {/* Hero Section */}
      <section className="relative h-screen w-full overflow-hidden flex items-center justify-center">
        <div className="absolute inset-0 z-0 bg-[#0A0F1E]">
          <img 
            src="https://postimg.cc/cKRd60Rk"
            alt="Hero Background"
            loading="lazy"
            decoding="async"
            onLoad={() => setImgLoaded(true)}
            onError={handleImgError}
            className={`w-full h-full object-cover transition-all duration-[3000ms] ease-out ${imgLoaded ? 'opacity-40 scale-100' : 'opacity-0 scale-110'}`}
          />
        </div>
        
        <div className="absolute inset-0 bg-gradient-to-b from-[#0F172A]/80 via-transparent to-[#0F172A] z-1"></div>
        
        <div className="container mx-auto px-6 relative z-10 text-center">
          <div className="inline-block mb-6 overflow-hidden">
            <span className="text-[#D4AF37] tracking-[0.8em] text-[10px] md:text-xs font-bold block animate-in slide-in-from-bottom-full duration-1000 uppercase">
              A Arte em Pedras Nobres
            </span>
          </div>
          
          <h1 className="text-white text-6xl md:text-8xl lg:text-9xl font-serif leading-[0.9] mb-12 animate-in slide-in-from-bottom duration-1000 delay-200">
            Design <span className="text-[#D4AF37] italic">Eterno</span><br/>
            Luxo Sólido.
          </h1>
          
          <div className="flex flex-col md:flex-row items-center justify-center space-y-6 md:space-y-0 md:space-x-8 animate-in fade-in duration-1000 delay-500">
            <button 
              onClick={() => onNavigate('budget')}
              className="bg-[#D4AF37] text-[#0F172A] px-14 py-6 rounded-full font-bold tracking-[0.3em] hover:bg-white transition-all transform hover:-translate-y-1 shadow-[0_20px_40px_rgba(212,175,55,0.2)] text-[10px]"
            >
              SOLICITAR ORÇAMENTO
            </button>
            <button 
              onClick={() => onNavigate('catalog')}
              className="bg-transparent border border-white/20 text-white px-14 py-6 rounded-full font-bold tracking-[0.3em] hover:bg-white hover:text-[#0F172A] transition-all text-[10px] backdrop-blur-sm"
            >
              VER COLEÇÕES
            </button>
          </div>
        </div>

        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce opacity-40">
          <div className="w-[1px] h-16 bg-gradient-to-b from-transparent via-[#D4AF37] to-transparent"></div>
        </div>
      </section>

      {/* Featured Section */}
      <section ref={sectionRef} className="py-40 bg-[#0F172A] relative overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row justify-between items-end mb-24 space-y-8 lg:space-y-0">
            <div className="max-w-2xl">
              <span className="text-[#D4AF37] tracking-[0.5em] text-[10px] font-bold mb-4 block uppercase">Obras da Natureza</span>
              <h2 className="text-white text-5xl md:text-6xl font-serif leading-tight">Destaques da <span className="text-[#D4AF37] italic">Curadoria</span></h2>
            </div>
            <button 
              onClick={() => onNavigate('catalog')}
              className="text-white text-[10px] font-bold tracking-[0.4em] border-b border-[#D4AF37]/40 pb-2 hover:border-[#D4AF37] transition-all uppercase"
            >
              Explorar Catálogo Completo
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {MATERIALS.slice(0, 3).map((material, idx) => (
              <div 
                key={material.id}
                onClick={() => onNavigate('catalog')}
                className={`group cursor-pointer relative overflow-hidden rounded-[32px] aspect-[3/4] transition-all duration-700 ${sectionVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}
                style={{ transitionDelay: `${idx * 200}ms` }}
              >
                <img 
                  src={material.image} 
                  alt={material.name}
                  loading="lazy"
                  decoding="async"
                  onError={handleImgError}
                  className="w-full h-full object-cover transition-transform duration-[2s] group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-[#0F172A]/20 to-transparent opacity-80 group-hover:opacity-60 transition-opacity"></div>
                <div className="absolute bottom-10 left-10 right-10">
                  <span className="text-[#D4AF37] text-[10px] font-bold tracking-[0.4em] mb-3 block uppercase">{material.category}</span>
                  <h3 className="text-white text-3xl font-serif group-hover:text-[#D4AF37] transition-colors">{material.name}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
