
import React, { useState } from 'react';
import { MATERIALS } from '../constants';
import { MaterialCategory } from '../types';

interface CatalogProps {
  onSelectMaterial: (id: string) => void;
}

// Subcomponente para gerenciar o Lazy Loading com Shimmer
const CatalogItemImage: React.FC<{ src: string; alt: string; onError: (e: any) => void }> = ({ src, alt, onError }) => {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div className="relative w-full h-full bg-slate-900 overflow-hidden">
      {/* Shimmer Effect - Exibido enquanto a imagem não carrega */}
      {!isLoaded && (
        <div className="absolute inset-0 z-0">
          <div className="w-full h-full bg-gradient-to-r from-transparent via-white/5 to-transparent animate-[shimmer_2s_infinite] -translate-x-full"></div>
        </div>
      )}
      
      <img 
        src={src} 
        alt={alt} 
        onError={onError}
        onLoad={() => setIsLoaded(true)}
        loading="lazy"
        decoding="async"
        className={`w-full h-full object-cover transition-all duration-[1.5s] ease-out ${
          isLoaded ? 'opacity-80 group-hover:opacity-100 scale-100' : 'opacity-0 scale-105'
        } group-hover:scale-110`}
      />
    </div>
  );
};

const Catalog: React.FC<CatalogProps> = ({ onSelectMaterial }) => {
  const [filter, setFilter] = useState<MaterialCategory | 'All'>('All');

  const filteredMaterials = filter === 'All' 
    ? MATERIALS 
    : MATERIALS.filter(m => m.category === filter);

  const categories = ['All', ...Object.values(MaterialCategory)];

  const handleImgError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    e.currentTarget.src = "https://images.unsplash.com/photo-1516961642265-531546e84af2?auto=format,compress&fit=crop&w=800&q=70";
  };

  return (
    <div className="pt-32 pb-24 bg-[#0F172A] min-h-screen animate-in fade-in duration-500">
      <style>{`
        @keyframes shimmer {
          100% { transform: translateX(100%); }
        }
      `}</style>
      
      <div className="container mx-auto px-6">
        <header className="mb-20 text-center">
          <span className="text-[#D4AF37] tracking-[0.5em] text-[10px] font-bold mb-4 block uppercase">Curadoria Soberano</span>
          <h1 className="text-white text-5xl md:text-7xl font-serif mb-6 leading-tight">Coleções <span className="text-[#D4AF37] italic">Nobres</span></h1>
          <p className="text-slate-400 max-w-2xl mx-auto font-light text-lg md:text-xl leading-relaxed">
            Selecione entre os materiais mais desejados da arquitetura internacional, selecionados por nossa curadoria técnica.
          </p>
        </header>

        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-20 max-w-5xl mx-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat as any)}
              className={`px-8 py-3.5 rounded-full text-[10px] font-bold tracking-[0.2em] transition-all duration-500 border ${
                filter === cat 
                  ? 'bg-[#D4AF37] text-[#0F172A] border-[#D4AF37] shadow-[0_10px_30px_rgba(212,175,55,0.2)] scale-105' 
                  : 'bg-white/5 text-slate-400 border-white/10 hover:border-[#D4AF37]/50 hover:text-white'
              }`}
            >
              {cat === 'All' ? 'TODOS' : cat.toUpperCase()}
            </button>
          ))}
        </div>

        {/* Grid com Lazy Loading */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {filteredMaterials.map((material) => (
            <div 
              key={material.id} 
              onClick={() => onSelectMaterial(material.id)}
              className="group bg-white/[0.03] overflow-hidden shadow-2xl transition-all duration-700 rounded-[32px] border border-white/5 hover:border-[#D4AF37]/20 cursor-pointer flex flex-col h-full relative"
            >
              <div className="relative h-80 overflow-hidden bg-slate-900">
                <CatalogItemImage 
                  src={material.image} 
                  alt={material.name} 
                  onError={handleImgError} 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-transparent to-transparent opacity-60 pointer-events-none"></div>
                <div className="absolute top-8 left-8">
                  <span className="bg-[#0F172A]/80 text-[#D4AF37] text-[9px] font-bold tracking-[0.3em] px-5 py-2 backdrop-blur-md rounded-full border border-[#D4AF37]/20 uppercase">
                    {material.category}
                  </span>
                </div>
              </div>
              <div className="p-10 flex flex-col flex-1">
                <h3 className="text-white text-3xl font-serif group-hover:text-[#D4AF37] transition-colors duration-500">{material.name}</h3>
                <p className="text-[#D4AF37] text-[10px] font-bold tracking-[0.4em] mt-3 uppercase opacity-70">{material.origin}</p>
                <p className="text-slate-400 text-sm mt-6 mb-10 leading-relaxed line-clamp-2 font-light italic">
                  "{material.description}"
                </p>
                <div className="mt-auto pt-8 border-t border-white/5 flex items-center justify-between group-hover:border-[#D4AF37]/20 transition-colors">
                  <span className="text-white text-[10px] font-bold tracking-[0.3em] group-hover:text-[#D4AF37]">EXPLORAR MATERIAL</span>
                  <i className="fas fa-chevron-right text-[#D4AF37] text-[8px]"></i>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Catalog;
