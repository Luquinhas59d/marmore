
import React from 'react';

const Location: React.FC = () => {
  return (
    <div className="bg-[#0F172A] min-h-screen animate-in fade-in duration-1000">
      {/* Hero Header */}
      <section className="pt-48 pb-20 container mx-auto px-6 text-center">
        <span className="text-[#D4AF37] tracking-[0.6em] text-[10px] font-bold mb-6 block uppercase">Nossa Sede Própria</span>
        <h1 className="text-white text-5xl md:text-7xl font-serif mb-8">Onde a <span className="text-[#D4AF37] italic">Excelência</span> Reside</h1>
        <p className="text-slate-400 text-lg md:text-xl font-light max-w-2xl mx-auto leading-relaxed">
          Localizada estrategicamente no coração industrial de Salto, nossa sede combina showroom exclusivo e pátio tecnológico de cortes.
        </p>
      </section>

      {/* Map & Info Section */}
      <section className="py-20 container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-stretch">
          
          {/* Contact Cards */}
          <div className="lg:col-span-1 space-y-6">
            <div className="glass p-10 rounded-[40px] border-white/10 hover:border-[#D4AF37]/30 transition-all group">
              <div className="w-12 h-12 bg-[#D4AF37]/10 rounded-2xl flex items-center justify-center mb-6 border border-[#D4AF37]/20 group-hover:bg-[#D4AF37] transition-all">
                <i className="fas fa-map-marked-alt text-[#D4AF37] group-hover:text-midnight"></i>
              </div>
              <h3 className="text-white text-xl font-serif mb-4">Endereço</h3>
              <p className="text-slate-400 font-light leading-relaxed">
                Rua das Pedras, 1000<br/>
                Distrito Industrial - Salto/SP<br/>
                CEP: 13320-000
              </p>
            </div>

            <div className="glass p-10 rounded-[40px] border-white/10 hover:border-[#D4AF37]/30 transition-all group">
              <div className="w-12 h-12 bg-[#D4AF37]/10 rounded-2xl flex items-center justify-center mb-6 border border-[#D4AF37]/20 group-hover:bg-[#D4AF37] transition-all">
                <i className="fas fa-clock text-[#D4AF37] group-hover:text-midnight"></i>
              </div>
              <h3 className="text-white text-xl font-serif mb-4">Horário de Atendimento</h3>
              <ul className="text-slate-400 font-light space-y-2">
                <li className="flex justify-between"><span>Segunda - Sexta:</span> <span className="text-white">08:00 - 18:00</span></li>
                <li className="flex justify-between"><span>Sábado:</span> <span className="text-white">08:00 - 12:00</span></li>
                <li className="text-[#D4AF37] text-xs pt-2 italic">* Atendimento com hora marcada disponível</li>
              </ul>
            </div>

            <button 
              onClick={() => window.open('https://maps.google.com/?q=Salto+SP', '_blank')}
              className="w-full bg-[#D4AF37] text-midnight py-6 rounded-full font-bold tracking-[0.3em] text-[10px] hover:bg-white transition-all transform hover:-translate-y-1 shadow-lg shadow-[#D4AF37]/10 flex items-center justify-center space-x-3"
            >
              <i className="fas fa-location-arrow"></i>
              <span>ABRIR NO GOOGLE MAPS</span>
            </button>
          </div>

          {/* Interactive Map */}
          <div className="lg:col-span-2 relative min-h-[500px] rounded-[40px] overflow-hidden border border-white/5 shadow-2xl">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3663.7431284564883!2d-47.28821032395642!3d-23.23420897893153!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94cf5aa55f69c6f5%3A0x88f28d75471d8892!2sSalto%2C%20SP!5e0!3m2!1spt-BR!2sbr!4v1700000000000!5m2!1spt-BR!2sbr" 
              className="absolute inset-0 w-full h-full border-0 grayscale invert contrast-75 opacity-70"
              allowFullScreen={true}
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-midnight via-transparent to-transparent"></div>
          </div>
        </div>
      </section>

      {/* Regions Section */}
      <section className="py-32 bg-white/[0.02] border-y border-white/5">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-white text-3xl font-serif mb-16 italic">Atendimento Especializado em Toda a Região</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {['SALTO', 'ITU', 'INDAIATUBA', 'SOROCABA'].map((city) => (
              <div key={city} className="flex flex-col items-center">
                <div className="w-1 h-8 bg-[#D4AF37]/30 mb-4"></div>
                <span className="text-white tracking-[0.4em] font-bold text-xs">{city}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Location;
